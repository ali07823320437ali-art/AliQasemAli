مدير حياتي - مشروع Android APK

هذا مشروع أندرويد جاهز للبناء، ويضمّن صفحة HTML داخل التطبيق لتعمل دون إنترنت.

لإنشاء APK على الكمبيوتر:
1) ثبّت Android Studio.
2) فك ضغط AliLifeManager.zip.
3) من Android Studio اختر Open وافتح مجلد AliLifeManager.
4) انتظر انتهاء Gradle Sync.
5) اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) سيظهر ملف APK داخل app/build/outputs/apk/debug/app-debug.apk.

للبناء من الهاتف فقط، يمكن تجربة AndroidIDE مع فتح المشروع، لكن قد يحتاج إعداد SDK/Gradle وذاكرة كافية.

ملاحظة: هذا أرشيف مشروع مصدر وليس ملف APK جاهزًا للتثبيت. لا تحذف بيانات التطبيق من إعدادات أندرويد إذا أردت الاحتفاظ ببياناته المحلية.
